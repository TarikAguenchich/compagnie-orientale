/* =========================================================
   CONFIG — à remplir avec les infos de ton projet Supabase
   (Supabase > Project Settings > API)
   ========================================================= */
const SUPABASE_URL      = "https://XXXXXXXX.supabase.co";
const SUPABASE_ANON_KEY = "COLLE_ICI_LA_CLE_ANON_PUBLIQUE";
const LOGIN_DOMAINE     = "compagnie.example";   // doit être identique au secret LOGIN_DOMAINE
const MONNAIE           = "septims";

const INTENDANTS = [
  { nom: "Motuu",       coffre: "Coffre de Motuu",       lieux: ["Solitude", "Morthal", "Markarth"] },
  { nom: "Bérin Pépin", coffre: "Coffre de Bérin Pépin", lieux: ["Vendeaume", "Fort-Hiver", "Aubétoile", "Faillaise", "Blancherive", "Epervine"] },
];
const INSTITUTIONS = ["Thalmor", "Empire", "Académie des Mages"];

/* =========================================================
   Outils
   ========================================================= */
const $ = id => document.getElementById(id);
const fmt = n => n.toLocaleString("fr-FR") + " " + MONNAIE;
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const dateFR = s => s ? s.split("-").reverse().join("/") : "";
const lib = x => x.nom + (x.var ? " — " + x.var : "");
function flash(el, t, ok) { el.className = "msg " + (ok ? "ok" : "err"); el.textContent = t; if (ok) setTimeout(() => { el.className = "msg"; }, 3500); }

function confirmer(txt) {
  return new Promise(res => {
    $("modalTxt").textContent = txt; $("modal").hidden = false; $("modalYes").focus();
    const fin = v => { $("modal").hidden = true; $("modalYes").onclick = $("modalNo").onclick = null; res(v); };
    $("modalYes").onclick = () => fin(true);
    $("modalNo").onclick = () => fin(false);
  });
}

// Désactive un bouton pendant une action serveur
async function occupe(btn, fn) {
  if (btn) btn.disabled = true; document.body.classList.add("busy");
  try { return await fn(); } finally { if (btn) btn.disabled = false; document.body.classList.remove("busy"); }
}

const configOk = !SUPABASE_URL.includes("XXXXXXXX") && !SUPABASE_ANON_KEY.startsWith("COLLE_");
const sb = configOk ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

// Message d'erreur lisible depuis une fonction serveur
async function erreurFonction(error) {
  try { const j = await error.context.json(); if (j?.error) return j.error; } catch {}
  return error?.message || String(error);
}

/* =========================================================
   Données
   ========================================================= */
let PROFIL = null;          // { id, login, role, intendant }
let CATALOGUE = [];         // articles (sans les ID)
let ITEM = {};
let IDS = {};               // admin uniquement : { nom: { item_id, var_ids } }
let HIST = [];
const estAdmin = () => PROFIL?.role === "admin";

async function chargerCatalogue() {
  const { data, error } = await sb.from("catalogue").select("*").order("ordre");
  if (error) throw error;
  CATALOGUE = data.map(a => ({ ...a, fourni: a.fourni || "" }));
  ITEM = Object.fromEntries(CATALOGUE.map(a => [a.nom, a]));
  IDS = {};
  if (estAdmin()) {
    const { data: ids, error: e2 } = await sb.from("catalogue_ids").select("*");
    if (e2) throw e2;
    IDS = Object.fromEntries(ids.map(r => [r.nom, r]));
  }
}

// Permanence en cours : gardée dans ce navigateur, par compte
let state, editId = null, restoring = false;
const cleEtat = () => "perm_state_" + (PROFIL?.login || "?");
function chargerEtat() {
  state = { intendant: 0, lieu: "", date: today(), orders: [], draft: null };
  try { const s = JSON.parse(localStorage.getItem(cleEtat())); if (s && Array.isArray(s.orders)) state = Object.assign(state, s); } catch {}
  editId = state.draft?.editId || null;
}
const save = () => { try { localStorage.setItem(cleEtat(), JSON.stringify(state)); } catch {} };

/* =========================================================
   Onglets
   ========================================================= */
function showTab(t) {
  if (t === "cat" && !estAdmin()) t = "perm";
  [["perm", "viewPerm", "tabPerm"], ["hist", "viewHist", "tabHist"], ["cat", "viewCat", "tabCat"]].forEach(([k, v, b]) => {
    $(v).hidden = t !== k; $(b).classList.toggle("on", t === k);
  });
  if (t === "hist") chargerHist();
  if (t === "cat") { renderCat(); chargerComptes(); }
  try { sessionStorage.setItem("tab", t); } catch {}
}
$("tabPerm").onclick = () => showTab("perm");
$("tabHist").onclick = () => showTab("hist");
$("tabCat").onclick = () => showTab("cat");

/* =========================================================
   Permanence en cours
   ========================================================= */
INTENDANTS.forEach((it, i) => $("intendant").add(new Option(it.nom, i)));
INSTITUTIONS.forEach(n => $("institutions").append(new Option(n)));

function majLieux() {
  if (PROFIL?.intendant) {
    const i = INTENDANTS.findIndex(x => x.nom === PROFIL.intendant);
    if (i >= 0) $("intendant").value = i;
  }
  $("intendant").disabled = !estAdmin();
  const it = INTENDANTS[$("intendant").value];
  $("lieu").innerHTML = "";
  it.lieux.forEach(l => $("lieu").add(new Option(l, l)));
  if (it.lieux.includes(state.lieu)) $("lieu").value = state.lieu;
  state.intendant = +$("intendant").value; state.lieu = $("lieu").value; save();
  render();
}
$("intendant").onchange = majLieux;
$("lieu").onchange = () => { state.lieu = $("lieu").value; save(); };
$("date").onchange = () => { state.date = $("date").value; save(); };

function remplirSelect(sel, garder) {
  sel.innerHTML = "";
  sel.add(new Option("— choisir un article —", ""));
  let cur = null, g = null;
  CATALOGUE.forEach(a => {
    if (a.cat !== cur) { g = document.createElement("optgroup"); g.label = a.cat; sel.append(g); cur = a.cat; }
    g.append(new Option(a.nom, a.nom));
  });
  if (garder) sel.value = garder;
}

function majVariante(tr, garder) {
  const a = ITEM[tr.querySelector(".item").value], v = tr.querySelector(".var");
  v.innerHTML = "";
  if (!a || !a.variantes) { v.hidden = true; return; }
  v.hidden = false;
  v.add(new Option("— variante —", ""));
  a.variantes.forEach(x => v.add(new Option(x, x)));
  if (garder && a.variantes.includes(garder)) v.value = garder;
}

function ajouterLigne(nom, qte, variante) {
  const tr = document.createElement("tr");
  tr.innerHTML = `<td><select class="item"></select><select class="var" hidden style="margin-top:6px"></select></td>
    <td class="qty"><input type="number" class="q" min="1" value="${qte || 1}"></td>
    <td class="cost"></td>
    <td class="del"><button type="button" class="x" title="Retirer">×</button></td>`;
  remplirSelect(tr.querySelector(".item"), nom || "");
  majVariante(tr, variante);
  tr.querySelector(".var").onchange = calcForm;
  tr.querySelector(".x").onclick = () => { tr.remove(); if (!$("lines").tBodies[0].children.length) ajouterLigne(); calcForm(); };
  tr.querySelector(".item").onchange = () => { majVariante(tr); calcForm(); };
  tr.querySelector(".q").oninput = calcForm;
  $("lines").tBodies[0].append(tr);
  calcForm();
}
$("addLine").onclick = () => ajouterLigne();

function lignesBrutes() {
  return [...document.querySelectorAll("#lines tbody tr")].map(tr => ({ nom: tr.querySelector(".item").value, var: tr.querySelector(".var").value, qte: parseInt(tr.querySelector(".q").value, 10) || 1 }));
}
function lignesForm() {
  const m = new Map();
  lignesBrutes().forEach(x => {
    if (!x.nom || !(x.qte > 0)) return;
    const k = x.nom + "|" + (x.var || "");
    m.set(k, (m.get(k) || 0) + x.qte);
  });
  return [...m].map(([k, qte]) => { const [nom, v] = k.split("|"); return v ? { nom, var: v, qte } : { nom, qte }; });
}

function coutTexte(a, q) {
  const parts = [];
  if (a.fourni) parts.push(q > 1 ? `${q}× (${a.fourni})` : a.fourni);
  parts.push(fmt(a.prix * q));
  return parts.join(" + ") + (a.note ? " — ⚠ " + a.note : "");
}

function saveDraft() {
  if (restoring || !state) return;
  state.draft = { editId, client: $("client").value, type: $("clientType").value, notes: $("notes").value, lines: lignesBrutes() };
  save();
}

function calcForm() {
  let tot = 0;
  document.querySelectorAll("#lines tbody tr").forEach(tr => {
    const a = ITEM[tr.querySelector(".item").value], q = parseInt(tr.querySelector(".q").value, 10) || 0;
    tr.querySelector(".cost").textContent = a ? coutTexte(a, q) : "";
    if (a) tot += a.prix * q;
  });
  $("orderTotal").textContent = tot ? "Total : " + fmt(tot) : "";
  saveDraft();
}
$("client").oninput = saveDraft;
$("clientType").onchange = saveDraft;
$("notes").oninput = saveDraft;

function modeEdition(o) {
  $("formTitle").textContent = o ? "Modifier la commande de " + o.client : "Nouvelle commande";
  $("saveOrder").textContent = o ? "Enregistrer la modification" : "Ajouter à la permanence";
  $("cancelEdit").style.display = o ? "" : "none";
  $("formCard").classList.toggle("editing", !!o);
}

function chargerForm(d) {
  restoring = true;
  $("client").value = d?.client || ""; $("clientType").value = d?.type || "Particulier"; $("notes").value = d?.notes || "";
  $("lines").tBodies[0].innerHTML = "";
  const ls = d?.lines?.length ? d.lines : [{ nom: "", qte: 1 }];
  ls.forEach(x => ajouterLigne(x.nom, x.qte, x.var));
  restoring = false;
  modeEdition(editId ? state.orders.find(o => o.id === editId) : null);
  saveDraft();
}

function resetForm() { editId = null; chargerForm(null); }
$("cancelEdit").onclick = resetForm;

$("saveOrder").onclick = () => {
  const client = $("client").value.trim(), items = lignesForm();
  if (!client) return flash($("formMsg"), "Renseigne le nom du client.", false);
  if (!items.length) return flash($("formMsg"), "Ajoute au moins un article.", false);
  const sansVar = items.find(x => ITEM[x.nom]?.variantes && !x.var);
  if (sansVar) return flash($("formMsg"), `Choisis la variante pour « ${sansVar.nom} ».`, false);
  // prix / fournitures / catégorie figés au moment de la commande
  const fig = items.map(x => { const a = ITEM[x.nom]; return Object.assign(x, { prix: a.prix, fourni: a.fourni || "", cat: a.cat }); });
  const o = { id: editId || Date.now().toString(36), client, type: $("clientType").value, notes: $("notes").value.trim(), items: fig };
  const edit = !!editId;
  if (edit) state.orders = state.orders.map(x => x.id === editId ? o : x);
  else state.orders.push(o);
  save();
  flash($("formMsg"), `Commande de ${client} ${edit ? "modifiée" : "ajoutée"}.`, true);
  resetForm(); render();
  $("client").focus();
};

/* ---------- Calculs & rendu ---------- */
const infos = x => ({ prix: x.prix ?? ITEM[x.nom]?.prix ?? 0, fourni: x.fourni ?? ITEM[x.nom]?.fourni ?? "", cat: x.cat ?? ITEM[x.nom]?.cat ?? "—" });
const totalOrder = o => o.items.reduce((s, x) => s + infos(x).prix * x.qte, 0);
const totalPerm = orders => orders.reduce((s, o) => s + totalOrder(o), 0);
function agreger(orders) {
  const m = new Map();
  orders.forEach(o => o.items.forEach(x => {
    const k = lib(x);
    if (!m.has(k)) m.set(k, { nom: k, base: x.nom, var: x.var || "", qte: 0, cat: infos(x).cat });
    m.get(k).qte += x.qte;
  }));
  const ordre = n => ITEM[n]?.ordre ?? 1e9;
  return [...m.values()].sort((a, b) => ordre(a.base) - ordre(b.base) || a.var.localeCompare(b.var));
}

function htmlCommandes(orders, actions, perm) {
  return orders.map((o, i) => {
    const livre = perm?.livraisons?.[o.id];
    return `<div class="order${perm && livre ? " livree" : ""}">
    <div class="order-head"><b>${i + 1}. ${esc(o.client)}</b><span class="hint">${esc(o.type)}</span>
      <span class="total" style="font-size:.9rem">${fmt(totalOrder(o))}</span></div>
    <ul>${o.items.map(x => { const a = infos(x); return `<li>${x.qte} × ${esc(lib(x))}${a.fourni ? ` <span class="hint">— fournit : ${esc(a.fourni)}${x.qte > 1 ? " (×" + x.qte + ")" : ""}</span>` : ""}</li>`; }).join("")}</ul>
    ${o.notes ? `<div class="meta">📝 ${esc(o.notes)}</div>` : ""}
    ${perm ? `<div class="row" style="margin-top:8px"><label class="liv"><input type="checkbox" data-liv="${perm.id}|${esc(o.id)}" ${livre ? "checked" : ""}> Livré</label>
      ${livre ? `<span class="hint">le ${new Date(livre).toLocaleString("fr-FR")}</span>` : ""}</div>` : ""}
    ${actions ? `<div class="row" style="margin-top:8px"><button class="btn small" data-e="${o.id}">Modifier</button><button class="btn small" data-d="${o.id}">Supprimer</button></div>` : ""}
  </div>`;
  }).join("");
}
function htmlRecap(orders, coffre) {
  const ag = agreger(orders), nb = ag.reduce((s, x) => s + x.qte, 0);
  return `<table><thead><tr><th style="text-align:right">Qté</th><th>Article</th><th>Catégorie</th></tr></thead><tbody>
    ${ag.map(x => `<tr><td class="n">${x.qte}</td><td>${esc(x.nom)}</td><td class="hint">${esc(x.cat)}</td></tr>`).join("")}
    </tbody></table>
    <div class="row" style="margin-top:10px"><span class="hint">${orders.length} client(s) — ${nb} article(s) — coffre : ${esc(coffre)}</span>
    <span class="total">Encaissé : ${fmt(totalPerm(orders))}</span></div>`;
}

function render() {
  if (!state) return;
  $("nbOrders").textContent = state.orders.length;
  const box = $("orders");
  box.innerHTML = state.orders.length ? htmlCommandes(state.orders, true) : '<p class="empty">Aucune commande enregistrée pour l\'instant.</p>';
  box.querySelectorAll("[data-d]").forEach(b => b.onclick = async () => {
    const o = state.orders.find(x => x.id === b.dataset.d);
    if (!await confirmer(`Supprimer la commande de ${o.client} ?`)) return;
    state.orders = state.orders.filter(x => x.id !== b.dataset.d); save();
    if (editId === b.dataset.d) resetForm();
    render();
  });
  box.querySelectorAll("[data-e]").forEach(b => b.onclick = () => {
    const o = state.orders.find(x => x.id === b.dataset.e);
    editId = o.id;
    chargerForm({ client: o.client, type: o.type, notes: o.notes, lines: o.items });
    $("formCard").scrollIntoView({ behavior: "smooth" });
  });
  $("recap").innerHTML = state.orders.length ? htmlRecap(state.orders, INTENDANTS[state.intendant].coffre) : '<p class="empty">Le récapitulatif apparaîtra ici.</p>';
}

/* ---------- Clôture ---------- */
async function envoyerDiscord(id) {
  const { error } = await sb.functions.invoke("envoyer-discord", { body: { permanence_id: id } });
  if (error) throw new Error(await erreurFonction(error));
}

$("send").onclick = () => occupe($("send"), async () => {
  if (!state.orders.length) return flash($("sendMsg"), "Aucune commande dans cette permanence.", false);
  if (!state.date) return flash($("sendMsg"), "Renseigne la date.", false);
  if (!await confirmer(`Clôturer la permanence (${state.orders.length} client(s)) et envoyer la commande à l'administration ?`)) return;

  const it = INTENDANTS[state.intendant];
  const { data: p, error } = await sb.from("permanences")
    .insert({ intendant: it.nom, coffre: it.coffre, lieu: state.lieu, date: state.date, orders: state.orders })
    .select().single();
  if (error) return flash($("sendMsg"), "Impossible d'enregistrer la permanence : " + error.message + ". Rien n'a été effacé.", false);

  // Enregistrée côté serveur : on vide la permanence locale
  state.orders = []; editId = null; state.draft = null; save();
  resetForm(); render();

  try {
    await envoyerDiscord(p.id);
    flash($("sendMsg"), "Commande envoyée à l'administration ✔ Permanence clôturée et archivée dans l'historique.", true);
  } catch (e) {
    flash($("sendMsg"), `Permanence clôturée et archivée, mais pas envoyée sur Discord (${e.message}). Tu pourras la renvoyer depuis l'onglet Historique.`, false);
  }
});

$("reset").onclick = async () => {
  if (!state.orders.length && !$("client").value && !lignesForm().length) return;
  if (!await confirmer("Effacer toutes les commandes de cette permanence sans rien envoyer ?")) return;
  state.orders = []; state.draft = null; editId = null; save(); resetForm(); render();
};

/* =========================================================
   Historique (partagé, lu depuis le serveur)
   ========================================================= */
INTENDANTS.forEach(it => $("fInt").add(new Option(it.nom, it.nom)));
[...new Set(INTENDANTS.flatMap(it => it.lieux))].forEach(l => $("fLieu").add(new Option(l, l)));
$("fInt").onchange = $("fLieu").onchange = $("fClient").oninput = renderHist;
$("histRefresh").onclick = () => chargerHist();

async function chargerHist() {
  $("histInfo").textContent = "Chargement…";
  const { data, error } = await sb.from("permanences").select("*").order("cloture_le", { ascending: false }).limit(300);
  if (error) { $("histInfo").textContent = "Erreur : " + error.message; return; }
  HIST = data;
  $("histInfo").textContent = `${HIST.length} permanence(s)` + (estAdmin() ? " — tous les intendants" : " — les tiennes");
  renderHist();
}

function renderHist() {
  const fi = $("fInt").value, fl = $("fLieu").value, fc = $("fClient").value.trim().toLowerCase();
  const list = HIST.filter(p => (!fi || p.intendant === fi) && (!fl || p.lieu === fl) &&
    (!fc || p.orders.some(o => o.client.toLowerCase().includes(fc))));
  const box = $("hist");
  if (!HIST.length) { box.innerHTML = '<p class="empty">Aucune permanence clôturée pour l\'instant.</p>'; return; }
  if (!list.length) { box.innerHTML = '<p class="empty">Aucune permanence ne correspond aux filtres.</p>'; return; }
  const ouverts = new Set([...box.querySelectorAll("details[open]")].map(d => d.dataset.id));
  box.innerHTML = list.map(p => {
    const nb = p.orders.reduce((s, o) => s + o.items.reduce((t, x) => t + x.qte, 0), 0);
    const liv = p.orders.filter(o => p.livraisons?.[o.id]).length, fini = liv === p.orders.length;
    return `<details class="perm ${fini ? "done" : "pending"}" data-id="${p.id}" ${ouverts.has(p.id) ? "open" : ""}>
      <summary><b>${esc(p.lieu)} — ${dateFR(p.date)}</b><span class="hint">${esc(p.intendant)} · ${p.orders.length} client(s) · ${nb} article(s)</span>
        ${p.discord ? '<span class="tag ok">Envoyée</span>' : '<span class="tag err">Non envoyée sur Discord</span>'}
        <span class="tag ${fini ? "ok" : ""}">${fini ? "✔ Tout livré" : `Livré ${liv}/${p.orders.length}`}</span>
        <span class="total" style="font-size:.9rem">${fmt(totalPerm(p.orders))}</span></summary>
      <div class="body">
        <div class="hint">Clôturée le ${new Date(p.cloture_le).toLocaleString("fr-FR")}${p.discord && p.envoye_le ? " — envoyée le " + new Date(p.envoye_le).toLocaleString("fr-FR") : ""}</div>
        <h3>Commandé à l'administration</h3>${htmlRecap(p.orders, p.coffre)}
        <h3>Commandes détaillées</h3>${htmlCommandes(p.orders, false, p)}
        <div class="row" style="margin-top:8px">
          ${p.discord ? "" : `<button class="btn small primary" data-hs="${p.id}">Envoyer sur Discord</button>`}
          ${estAdmin() ? `<button class="btn small" data-hd="${p.id}">Supprimer de l'historique</button>` : ""}
        </div>
        <div class="msg" id="hm-${p.id}"></div>
      </div></details>`;
  }).join("");

  box.querySelectorAll("[data-liv]").forEach(c => c.onchange = async () => {
    const [pid, oid] = c.dataset.liv.split("|");
    const p = HIST.find(x => x.id === pid);
    const livraisons = Object.assign({}, p.livraisons);
    if (c.checked) livraisons[oid] = new Date().toISOString(); else delete livraisons[oid];
    c.disabled = true;
    const { data, error } = await sb.from("permanences").update({ livraisons }).eq("id", pid).select().single();
    if (error) { c.checked = !c.checked; c.disabled = false; return flash($("hm-" + pid), "Erreur : " + error.message, false); }
    Object.assign(p, data); renderHist();
  });
  box.querySelectorAll("[data-hs]").forEach(b => b.onclick = () => occupe(b, async () => {
    try { await envoyerDiscord(b.dataset.hs); await chargerHist(); }
    catch (e) { flash($("hm-" + b.dataset.hs), "Échec de l'envoi : " + e.message, false); }
  }));
  box.querySelectorAll("[data-hd]").forEach(b => b.onclick = async () => {
    if (!await confirmer("Supprimer définitivement cette permanence de l'historique ?")) return;
    const { error } = await sb.from("permanences").delete().eq("id", b.dataset.hd);
    if (error) return flash($("hm-" + b.dataset.hd), "Erreur : " + error.message, false);
    await chargerHist();
  });
}

/* =========================================================
   Administration : catalogue
   ========================================================= */
let catEdit = null;

async function apresModifCatalogue(msg) {
  await chargerCatalogue();
  document.querySelectorAll("#lines tbody tr").forEach(tr => {
    const sel = tr.querySelector(".item"), v = tr.querySelector(".var").value;
    remplirSelect(sel, sel.value); majVariante(tr, v);
  });
  calcForm(); render(); renderCat();
  if (msg) flash($("cMsg"), msg, true);
}

function resetCatForm() {
  catEdit = null;
  ["cCat", "cNom", "cPrix", "cId", "cFourni", "cVar", "cNote"].forEach(id => $(id).value = "");
  $("catFormTitle").textContent = "Ajouter un article";
  $("cSave").textContent = "Ajouter au catalogue";
  $("cCancel").style.display = "none";
  $("catFormCard").classList.remove("editing");
}
$("cCancel").onclick = resetCatForm;

// Position d'un article ajouté : à la fin de sa catégorie (ou à la fin du catalogue)
function ordreFinCategorie(cat, sauf) {
  const liste = CATALOGUE.filter(a => a.nom !== sauf);
  const dans = liste.filter(a => a.cat === cat);
  if (!dans.length) return (liste.at(-1)?.ordre ?? 0) + 10;
  const dernier = dans.at(-1).ordre;
  const suivant = liste.find(a => a.ordre > dernier)?.ordre;
  return suivant === undefined ? dernier + 10 : (dernier + suivant) / 2;
}

$("cSave").onclick = () => occupe($("cSave"), async () => {
  const cat = $("cCat").value.trim(), nom = $("cNom").value.trim(), prixTxt = $("cPrix").value.trim();
  const prix = Number(prixTxt);
  if (!cat) return flash($("cMsg"), "Renseigne la catégorie.", false);
  if (!nom) return flash($("cMsg"), "Renseigne le nom de l'article.", false);
  if (prixTxt === "" || !Number.isInteger(prix) || prix < 0) return flash($("cMsg"), "Renseigne un prix valide (nombre entier).", false);
  if (nom !== catEdit && ITEM[nom]) return flash($("cMsg"), `« ${nom} » existe déjà dans le catalogue.`, false);

  // "Blanc = 0A1B2C, Bleu" -> variantes + ID par variante
  const ancienIds = catEdit ? IDS[catEdit]?.var_ids : null;
  const vars = [], varIds = {};
  $("cVar").value.split(",").map(x => x.trim()).filter(Boolean).forEach(v => {
    const [n, ...r] = v.split("="); const nomV = n.trim(), idV = r.join("=").trim();
    if (!nomV || vars.includes(nomV)) return;
    vars.push(nomV);
    const garde = idV || ancienIds?.[nomV] || "";
    if (garde) varIds[nomV] = garde;
  });

  const ligne = { nom, cat, prix, fourni: $("cFourni").value.trim(), variantes: vars.length ? vars : null, note: $("cNote").value.trim() || null };
  let error;
  if (catEdit) {
    if (ITEM[catEdit].cat !== cat) ligne.ordre = ordreFinCategorie(cat, catEdit);
    ({ error } = await sb.from("catalogue").update(ligne).eq("nom", catEdit));
  } else {
    ligne.ordre = ordreFinCategorie(cat);
    ({ error } = await sb.from("catalogue").insert(ligne));
  }
  if (error) return flash($("cMsg"), "Erreur : " + error.message, false);

  const { error: e2 } = await sb.from("catalogue_ids").upsert({
    nom, item_id: $("cId").value.trim() || null, var_ids: vars.length && Object.keys(varIds).length ? varIds : null,
  });
  if (e2) return flash($("cMsg"), "Article enregistré, mais erreur sur l'ID : " + e2.message, false);

  const modif = !!catEdit;
  resetCatForm();
  await apresModifCatalogue(modif ? `« ${nom} » modifié.` : `« ${nom} » ajouté au catalogue.`);
});

const manqueId = a => a.variantes ? a.variantes.some(v => !IDS[a.nom]?.var_ids?.[v]) : !IDS[a.nom]?.item_id;
function majCompteurId() {
  const n = CATALOGUE.filter(manqueId).length;
  $("nbMissing").textContent = n ? `${n} article(s) sans ID complet` : "✔ Tous les articles ont un ID";
}

function renderCat() {
  if (!estAdmin()) return;
  $("nbArticles").textContent = CATALOGUE.length;
  $("catList").innerHTML = ""; [...new Set(CATALOGUE.map(a => a.cat))].forEach(c => $("catList").append(new Option(c)));
  majCompteurId();
  const q = $("cSearch").value.trim().toLowerCase(), seulSansId = $("cMissing").checked;
  const list = CATALOGUE.filter(a => {
    const ids = IDS[a.nom] || {};
    const txt = [a.nom, a.cat, a.fourni, ids.item_id, ...Object.values(ids.var_ids || {})].join(" ").toLowerCase();
    return (!q || txt.includes(q)) && (!seulSansId || manqueId(a));
  });
  if (!list.length) { $("catTable").innerHTML = '<p class="empty">Aucun article.</p>'; return; }
  let cur = null, rows = "";
  list.forEach(a => {
    const ids = IDS[a.nom] || {};
    if (a.cat !== cur) { rows += `<tr class="cat-head"><td colspan="5">${esc(a.cat)}</td></tr>`; cur = a.cat; }
    const idCell = a.variantes
      ? a.variantes.map(v => `<div class="id-var">${esc(v)} <input class="id-input${ids.var_ids?.[v] ? "" : " missing"}" data-idnom="${esc(a.nom)}" data-idvar="${esc(v)}" value="${esc(ids.var_ids?.[v] || "")}" placeholder="ID"></div>`).join("")
      : `<input class="id-input${ids.item_id ? "" : " missing"}" data-idnom="${esc(a.nom)}" value="${esc(ids.item_id || "")}" placeholder="ID">`;
    rows += `<tr class="cat-row"><td><b>${esc(a.nom)}</b>${a.variantes ? `<br><span class="hint">${a.variantes.length} variantes</span>` : ""}${a.note ? `<br><span class="hint">⚠ ${esc(a.note)}</span>` : ""}</td>
      <td class="f hint">${a.fourni ? "Fournit : " + esc(a.fourni) : ""}</td>
      <td class="p">${fmt(a.prix)}</td>
      <td class="idc">${idCell}</td>
      <td class="act"><button class="btn small" data-ce="${esc(a.nom)}">Modifier</button> <button class="btn small" data-cd="${esc(a.nom)}">Supprimer</button></td></tr>`;
  });
  $("catTable").innerHTML = `<table><thead><tr><th>Article</th><th>À fournir</th><th style="text-align:right">Prix</th><th style="text-align:right">ID give</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;

  $("catTable").querySelectorAll("[data-ce]").forEach(b => b.onclick = () => {
    const a = ITEM[b.dataset.ce], ids = IDS[a.nom] || {};
    catEdit = a.nom;
    $("cCat").value = a.cat; $("cNom").value = a.nom; $("cPrix").value = a.prix;
    $("cId").value = ids.item_id || "";
    $("cFourni").value = a.fourni || ""; $("cNote").value = a.note || "";
    $("cVar").value = (a.variantes || []).map(v => ids.var_ids?.[v] ? `${v} = ${ids.var_ids[v]}` : v).join(", ");
    $("catFormTitle").textContent = "Modifier « " + a.nom + " »";
    $("cSave").textContent = "Enregistrer la modification";
    $("cCancel").style.display = "";
    $("catFormCard").classList.add("editing");
    $("catFormCard").scrollIntoView({ behavior: "smooth" });
  });

  // Édition directe des ID (sans re-rendu, pour garder le focus)
  $("catTable").querySelectorAll("[data-idnom]").forEach(inp => inp.onchange = async () => {
    const nom = inp.dataset.idnom, val = inp.value.trim();
    const r = { nom, item_id: IDS[nom]?.item_id || null, var_ids: Object.assign({}, IDS[nom]?.var_ids) };
    if (inp.dataset.idvar !== undefined) { if (val) r.var_ids[inp.dataset.idvar] = val; else delete r.var_ids[inp.dataset.idvar]; }
    else r.item_id = val || null;
    if (!Object.keys(r.var_ids).length) r.var_ids = null;
    inp.classList.add("saving");
    const { error } = await sb.from("catalogue_ids").upsert(r);
    inp.classList.remove("saving");
    if (error) { flash($("cMsg"), "Erreur en enregistrant l'ID : " + error.message, false); return; }
    IDS[nom] = r;
    inp.classList.toggle("missing", !val);
    majCompteurId();
  });

  $("catTable").querySelectorAll("[data-cd]").forEach(b => b.onclick = async () => {
    const nom = b.dataset.cd;
    if (!await confirmer(`Retirer « ${nom} » du catalogue ? Les commandes déjà enregistrées ne sont pas modifiées.`)) return;
    const { error } = await sb.from("catalogue").delete().eq("nom", nom);
    if (error) return flash($("cMsg"), "Erreur : " + error.message, false);
    if (catEdit === nom) resetCatForm();
    await apresModifCatalogue(`« ${nom} » retiré du catalogue.`);
  });
}
$("cSearch").oninput = renderCat;
$("cMissing").onchange = renderCat;

$("cExport").onclick = () => {
  const data = CATALOGUE.map(a => ({ ...a, item_id: IDS[a.nom]?.item_id || null, var_ids: IDS[a.nom]?.var_ids || null }));
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = "catalogue-" + today() + ".json";
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};

/* =========================================================
   Administration : comptes
   ========================================================= */
const optionsRole = sel => `<option value="admin"${sel === "admin" ? " selected" : ""}>Admin (accès complet)</option>` +
  INTENDANTS.map(it => `<option value="i:${esc(it.nom)}"${sel === "i:" + it.nom ? " selected" : ""}>Intendant — ${esc(it.nom)}</option>`).join("");
$("gRole").innerHTML = optionsRole("i:" + INTENDANTS[0].nom);
const lireRole = v => v === "admin" ? { role: "admin" } : { role: "intendant", intendant: v.slice(2) };

async function appelComptes(body) {
  const { data, error } = await sb.functions.invoke("admin-comptes", { body });
  if (error) throw new Error(await erreurFonction(error));
  return data;
}

async function chargerComptes() {
  if (!estAdmin()) return;
  $("comptes").innerHTML = '<p class="hint">Chargement des comptes…</p>';
  try {
    const { comptes } = await appelComptes({ action: "lister" });
    $("comptes").innerHTML = `<table class="comptes-table"><thead><tr><th>Identifiant</th><th>Rôle</th><th>Nouveau mot de passe</th><th></th></tr></thead><tbody>
      ${comptes.map(c => `<tr>
        <td><b>${esc(c.login)}</b>${c.id === PROFIL.id ? ' <span class="hint">(toi)</span>' : ""}</td>
        <td><select data-crole="${c.id}">${optionsRole(c.role === "admin" ? "admin" : "i:" + c.intendant)}</select></td>
        <td><div class="pw"><input type="text" data-cpw="${c.id}" placeholder="8 caractères min." autocomplete="off"><button class="btn small" data-cpwgo="${c.id}">Changer</button></div></td>
        <td class="act">${c.id === PROFIL.id ? "" : `<button class="btn small" data-cdel="${c.id}" data-clogin="${esc(c.login)}">Supprimer</button>`}</td>
      </tr>`).join("")}</tbody></table>`;
    $("comptes").querySelectorAll("[data-crole]").forEach(s => s.onchange = () => occupe(s, async () => {
      try { await appelComptes({ action: "modifier", id: s.dataset.crole, ...lireRole(s.value) }); flash($("gMsg"), "Rôle modifié.", true); }
      catch (e) { flash($("gMsg"), e.message, false); await chargerComptes(); }
    }));
    $("comptes").querySelectorAll("[data-cpwgo]").forEach(b => b.onclick = () => occupe(b, async () => {
      const inp = $("comptes").querySelector(`[data-cpw="${b.dataset.cpwgo}"]`);
      try { await appelComptes({ action: "mot_de_passe", id: b.dataset.cpwgo, password: inp.value }); inp.value = ""; flash($("gMsg"), "Mot de passe changé.", true); }
      catch (e) { flash($("gMsg"), e.message, false); }
    }));
    $("comptes").querySelectorAll("[data-cdel]").forEach(b => b.onclick = async () => {
      if (!await confirmer(`Supprimer le compte « ${b.dataset.clogin} » ? Il ne pourra plus se connecter.`)) return;
      try { await appelComptes({ action: "supprimer", id: b.dataset.cdel }); flash($("gMsg"), "Compte supprimé.", true); await chargerComptes(); }
      catch (e) { flash($("gMsg"), e.message, false); }
    });
  } catch (e) {
    $("comptes").innerHTML = `<p class="msg err" style="display:block">Impossible de charger les comptes : ${esc(e.message)}</p>`;
  }
}

$("gGo").onclick = () => occupe($("gGo"), async () => {
  const login = $("gLogin").value.trim().toLowerCase(), password = $("gPass").value;
  if (!login || !password) return flash($("gMsg"), "Renseigne l'identifiant et le mot de passe.", false);
  try {
    await appelComptes({ action: "creer", login, password, ...lireRole($("gRole").value) });
    $("gLogin").value = ""; $("gPass").value = "";
    flash($("gMsg"), `Compte « ${login} » créé.`, true);
    await chargerComptes();
  } catch (e) { flash($("gMsg"), e.message, false); }
});

/* =========================================================
   Connexion / démarrage
   ========================================================= */
function ecranConnexion(msg) {
  $("app").hidden = true; $("loginScreen").hidden = false;
  if (msg) flash($("lMsg"), msg, false);
  $("lUser").focus();
}

async function demarrer(user) {
  const { data: prof, error } = await sb.from("profiles").select("*").eq("id", user.id).single();
  if (error || !prof) { await sb.auth.signOut(); return ecranConnexion("Ce compte n'a pas de profil. Contacte l'admin."); }
  if (prof.role !== "admin" && !INTENDANTS.some(it => it.nom === prof.intendant)) {
    await sb.auth.signOut(); return ecranConnexion("Ce compte n'est rattaché à aucun intendant. Contacte l'admin.");
  }
  PROFIL = prof;
  try { await chargerCatalogue(); }
  catch (e) { await sb.auth.signOut(); return ecranConnexion("Impossible de charger le catalogue : " + e.message); }

  $("loginScreen").hidden = true; $("app").hidden = false;
  $("userInfo").innerHTML = `Connecté : <b>${esc(PROFIL.login)}</b> — ${estAdmin() ? "Admin" : "Intendant (" + esc(PROFIL.intendant) + ")"}`;
  $("tabCat").hidden = !estAdmin();
  $("fIntWrap").hidden = !estAdmin();
  chargerEtat();
  $("intendant").value = state.intendant;
  $("date").value = state.date || today();
  majLieux();
  chargerForm(state.draft);
  render();
  let t0 = "perm"; try { t0 = sessionStorage.getItem("tab") || "perm"; } catch {}
  showTab(t0);
}

$("loginForm").onsubmit = e => {
  e.preventDefault();
  occupe($("lGo"), async () => {
    const login = $("lUser").value.trim().toLowerCase();
    const { data, error } = await sb.auth.signInWithPassword({ email: `${login}@${LOGIN_DOMAINE}`, password: $("lPass").value });
    $("lPass").value = "";
    if (error) return flash($("lMsg"), error.message.includes("Invalid") ? "Identifiant ou mot de passe incorrect." : error.message, false);
    await demarrer(data.user);
  });
};

$("logout").onclick = async () => {
  await sb.auth.signOut();
  PROFIL = null; state = null;
  try { sessionStorage.removeItem("tab"); } catch {}
  ecranConnexion();
};

(async () => {
  if (!configOk) {
    $("loginScreen").hidden = false;
    return flash($("lMsg"), "Le site n'est pas encore configuré : renseigne SUPABASE_URL et SUPABASE_ANON_KEY en haut de script.js.", false);
  }
  const { data: { session } } = await sb.auth.getSession();
  if (session?.user) await demarrer(session.user); else ecranConnexion();
})();
