# Registre des Intendants — installation avec Supabase

Contenu du dossier :

```
site/                        → le site (à héberger : GitHub Pages, Netlify…)
  index.html  style.css  script.js
supabase/
  1_schema.sql               → tables + règles de sécurité
  2_catalogue.sql            → les 160 articles du catalogue
  functions/envoyer-discord/index.ts   → envoi sur Discord (côté serveur)
  functions/admin-comptes/index.ts     → gestion des comptes (admin)
```

Qui voit quoi :

| | Intendant | Admin |
|---|---|---|
| Permanence en cours | ✔ (son intendant uniquement, verrouillé) | ✔ (tous) |
| Historique | ✔ ses permanences | ✔ toutes + suppression |
| Cocher « Livré » / renvoyer sur Discord | ✔ | ✔ |
| Onglet Administration (catalogue, ID, comptes) | ✘ | ✔ |
| ID de give | jamais visibles | ✔ |
| Adresse du webhook Discord | jamais visible (stockée sur le serveur) | idem |

Tout est vérifié par le serveur : même en bricolant la page, un intendant ne peut ni lire les ID, ni modifier le catalogue, ni voir les permanences d'un autre intendant.

---

## 1. Créer le projet Supabase

1. Va sur https://supabase.com, crée un compte (gratuit), puis **New project**.
2. Nom : `compagnie` par ex. Région : **Europe (Paris ou Frankfurt)**. Note le mot de passe de la base quelque part (il ne servira pas au site).
3. Attends que le projet soit prêt (1-2 min).

## 2. Créer les tables

1. Menu de gauche → **SQL Editor** → **New query**.
2. Colle tout le contenu de `supabase/1_schema.sql` → **Run**. Tu dois voir « Success ».
3. Nouvelle requête, colle `supabase/2_catalogue.sql` → **Run**.
4. Vérification : **Table Editor** → table `catalogue` → 160 lignes.

## 3. Bloquer les inscriptions libres (important)

**Authentication → Sign In / Providers** (ou *Providers → Email* selon la version) :

- **Allow new users to sign up** → **désactivé**. Seul l'admin crée les comptes.
- **Confirm email** → désactivé (les comptes créés par l'admin sont déjà confirmés, mais ça évite tout blocage).

## 4. Créer les 2 fonctions serveur

Menu **Edge Functions** → **Deploy a new function** → **Via Editor** :

1. Nom : `envoyer-discord` → remplace le code d'exemple par tout le contenu de `supabase/functions/envoyer-discord/index.ts` → **Deploy**.
2. Recommence avec le nom `admin-comptes` et le fichier `supabase/functions/admin-comptes/index.ts`.

Laisse l'option **Verify JWT** activée (par défaut).

## 5. Renseigner les secrets

**Edge Functions → Secrets** (ou *Project Settings → Edge Functions*) → ajoute :

| Nom | Valeur |
|---|---|
| `DISCORD_WEBHOOK_URL` | l'URL du webhook du salon Discord |
| `DISCORD_ROLE_ID` | l'ID du rôle modo à pinger (facultatif) |
| `LOGIN_DOMAINE` | `compagnie.example` |

## 6. Créer ton compte admin

1. **Authentication → Users → Add user → Create new user**
   - Email : `admin@compagnie.example` (la partie avant @ sera ton identifiant de connexion)
   - Mot de passe : le tien
   - Coche **Auto Confirm User** → **Create user**
2. **SQL Editor**, exécute :
   ```sql
   update public.profiles set role = 'admin', intendant = null where login = 'admin';
   ```

## 7. Brancher le site

1. **Project Settings → API** (ou *Data API* / *API Keys*) :
   - **Project URL** → ex. `https://abcdefgh.supabase.co`
   - **anon public key** (ou *publishable key* `sb_publishable_…`)
2. En haut de `site/script.js` :
   ```js
   const SUPABASE_URL      = "https://abcdefgh.supabase.co";
   const SUPABASE_ANON_KEY = "eyJhbGciOi...";      // clé anon / publishable
   const LOGIN_DOMAINE     = "compagnie.example";
   ```
   Cette clé est **publique par conception** : elle ne donne aucun droit sans connexion, ce sont les règles de sécurité de l'étape 2 qui protègent les données. **Ne mets jamais la clé `service_role` / `secret` dans le site.**
3. Mets le dossier `site/` en ligne (GitHub Pages, Netlify Drop…), ou ouvre `index.html` pour tester.

## 8. Créer les comptes des intendants

Connecte-toi avec `admin` → onglet **Administration** → bloc **Comptes** :
identifiant, mot de passe (8 caractères min.), rôle *Intendant — Motuu* / *Intendant — Bérin Pépin*… → **Créer le compte**.

Depuis ce même bloc : changer un mot de passe, changer le rôle, supprimer un compte.

---

## Ajouter un intendant ou une châtellerie

Dans `site/script.js`, bloc `INTENDANTS` : ajoute une ligne `{ nom, coffre, lieux }`. Le nom doit être **exactement** celui choisi à la création du compte.

## En cas de souci

- **« Identifiant ou mot de passe incorrect »** alors que c'est bon → vérifie que `LOGIN_DOMAINE` est identique dans `script.js`, dans les secrets, et dans l'email du compte (`xxx@compagnie.example`).
- **Création de compte refusée pour un problème d'email** → Supabase refuse parfois certains domaines : remplace `compagnie.example` par un autre (ex. `intendants.local`) **aux 3 endroits**, et recrée l'admin.
- **« Pas envoyée sur Discord »** → vérifie le secret `DISCORD_WEBHOOK_URL`, puis renvoie depuis l'onglet Historique. Les erreurs détaillées sont dans **Edge Functions → envoyer-discord → Logs**.
- **Projet en pause** → les projets gratuits Supabase peuvent être mis en pause après une période sans activité ; il suffit de le relancer depuis le tableau de bord.
