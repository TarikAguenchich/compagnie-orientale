// =====================================================================
//  Fonction serveur : gestion des comptes (réservée à l'admin).
//  Actions : lister, creer, mot_de_passe, modifier, supprimer
//  Secret facultatif : LOGIN_DOMAINE (doit être identique à celui de script.js)
// =====================================================================
import { createClient } from "npm:@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });

const LOGIN_OK = /^[a-z0-9._-]{2,32}$/;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const domaine = Deno.env.get("LOGIN_DOMAINE") ?? "compagnie.example";

    // Vérifie que l'appelant est admin (avec ses propres droits)
    const userClient = createClient(url, anon, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "Non connecté." }, 401);
    const { data: estAdmin } = await userClient.rpc("est_admin");
    if (!estAdmin) return json({ error: "Réservé à l'admin." }, 403);

    const admin = createClient(url, service, { auth: { autoRefreshToken: false, persistSession: false } });
    const body = await req.json();
    const role = body.role === "admin" ? "admin" : "intendant";
    const intendant = role === "intendant" ? (body.intendant || null) : null;

    switch (body.action) {
      case "lister": {
        const { data, error } = await admin.from("profiles").select("id, login, role, intendant").order("login");
        if (error) throw error;
        return json({ comptes: data });
      }
      case "creer": {
        const login = String(body.login ?? "").trim().toLowerCase();
        if (!LOGIN_OK.test(login)) return json({ error: "Identifiant invalide (lettres minuscules, chiffres, . _ -)." }, 400);
        if (String(body.password ?? "").length < 8) return json({ error: "Mot de passe trop court (8 caractères minimum)." }, 400);
        if (role === "intendant" && !intendant) return json({ error: "Choisis l'intendant rattaché." }, 400);
        const { error } = await admin.auth.admin.createUser({
          email: `${login}@${domaine}`, password: body.password, email_confirm: true,
          app_metadata: { login, role, intendant },
        });
        if (error) return json({ error: error.message.includes("already") ? "Cet identifiant existe déjà." : error.message }, 400);
        return json({ ok: true });
      }
      case "mot_de_passe": {
        if (String(body.password ?? "").length < 8) return json({ error: "Mot de passe trop court (8 caractères minimum)." }, 400);
        const { error } = await admin.auth.admin.updateUserById(body.id, { password: body.password });
        if (error) throw error;
        return json({ ok: true });
      }
      case "modifier": {
        if (body.id === user.id && role !== "admin") return json({ error: "Tu ne peux pas retirer ton propre accès admin." }, 400);
        if (role === "intendant" && !intendant) return json({ error: "Choisis l'intendant rattaché." }, 400);
        const { data: u } = await admin.auth.admin.getUserById(body.id);
        const { error: e1 } = await admin.auth.admin.updateUserById(body.id, { app_metadata: { ...(u?.user?.app_metadata ?? {}), role, intendant } });
        if (e1) throw e1;
        const { error: e2 } = await admin.from("profiles").update({ role, intendant }).eq("id", body.id);
        if (e2) throw e2;
        return json({ ok: true });
      }
      case "supprimer": {
        if (body.id === user.id) return json({ error: "Tu ne peux pas supprimer ton propre compte." }, 400);
        const { error } = await admin.auth.admin.deleteUser(body.id);
        if (error) throw error;
        return json({ ok: true });
      }
      default:
        return json({ error: "Action inconnue." }, 400);
    }
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});
