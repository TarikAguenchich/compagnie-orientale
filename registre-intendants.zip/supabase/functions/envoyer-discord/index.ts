// =====================================================================
//  Fonction serveur : envoie une permanence clôturée sur Discord.
//  Secrets à définir dans Supabase (Edge Functions > Secrets) :
//    DISCORD_WEBHOOK_URL  = l'URL du webhook du salon
//    DISCORD_ROLE_ID      = l'ID du rôle à pinger (facultatif)
// =====================================================================
import { createClient } from "npm:@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });

type Item = { nom: string; var?: string; qte: number; prix?: number };
type Order = { id: string; client: string; type: string; notes?: string; items: Item[] };

const fmt = (n: number) => n.toLocaleString("fr-FR").replace(/ | /g, " ") + " septims";
const lib = (x: Item) => x.nom + (x.var ? " — " + x.var : "");
const dateFR = (s: string) => s.split("-").reverse().join("/");
const totalOrder = (o: Order) => o.items.reduce((s, x) => s + (x.prix ?? 0) * x.qte, 0);

function chunks(lines: string[], max: number) {
  const out: string[] = []; let cur = "";
  for (const l of lines) {
    if (cur && (cur + "\n" + l).length > max) { out.push(cur); cur = l; }
    else cur = cur ? cur + "\n" + l : l;
  }
  if (cur) out.push(cur);
  return out;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const webhook = Deno.env.get("DISCORD_WEBHOOK_URL");
    const roleId = Deno.env.get("DISCORD_ROLE_ID") ?? "";
    if (!webhook) return json({ error: "Le secret DISCORD_WEBHOOK_URL n'est pas configuré." }, 500);

    // Client "utilisateur" : lit la permanence avec SES droits (vérifie qu'il y a accès)
    const userClient = createClient(url, anon, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "Non connecté." }, 401);

    const { permanence_id } = await req.json();
    const { data: p, error } = await userClient.from("permanences").select("*").eq("id", permanence_id).single();
    if (error || !p) return json({ error: "Permanence introuvable ou accès refusé." }, 403);

    // Client "serveur" : lit les ID de give (cachés aux intendants) et met à jour le statut
    const admin = createClient(url, service);
    const orders = p.orders as Order[];
    const noms = [...new Set(orders.flatMap((o) => o.items.map((x) => x.nom)))];
    const [{ data: ids }, { data: cat }] = await Promise.all([
      admin.from("catalogue_ids").select("nom, item_id, var_ids").in("nom", noms),
      admin.from("catalogue").select("nom, ordre").in("nom", noms),
    ]);
    const idsParNom = new Map((ids ?? []).map((r) => [r.nom, r]));
    const ordre = new Map((cat ?? []).map((r) => [r.nom, r.ordre]));
    const idOf = (x: Item) => {
      const r = idsParNom.get(x.nom);
      return (x.var ? r?.var_ids?.[x.var] : r?.item_id) || "";
    };

    // Regroupement tous clients confondus
    const m = new Map<string, { nom: string; base: string; var: string; qte: number; id: string }>();
    for (const o of orders) for (const x of o.items) {
      const k = lib(x);
      if (!m.has(k)) m.set(k, { nom: k, base: x.nom, var: x.var ?? "", qte: 0, id: idOf(x) });
      m.get(k)!.qte += x.qte;
    }
    const ag = [...m.values()].sort((a, b) =>
      (ordre.get(a.base) ?? 1e9) - (ordre.get(b.base) ?? 1e9) || a.var.localeCompare(b.var));
    const nb = ag.reduce((s, x) => s + x.qte, 0);
    const total = orders.reduce((s, o) => s + totalOrder(o), 0);
    const titre = `Permanence ${p.lieu} — ${dateFR(p.date)}`;

    const embeds: Record<string, unknown>[] = chunks(
      ag.map((x) => `\`${String(x.qte).padStart(3)}\` × **${x.nom}** — ID : ${x.id ? "`" + x.id + "`" : "⚠ manquant"}`),
      3800,
    ).map((txt, i) => ({ title: i === 0 ? `📦 Commande à l'administration — ${titre}` : "📦 (suite)", description: txt, color: 0x7a1f1a }));
    const fields = [
      { name: "Intendant", value: p.intendant, inline: true },
      { name: "Coffre de dépôt", value: p.coffre, inline: true },
      { name: "Volume", value: `${orders.length} client(s) · ${nb} article(s)`, inline: true },
    ];
    const sansId = ag.filter((x) => !x.id).length;
    if (sansId) fields.push({ name: "⚠ Attention", value: `${sansId} article(s) sans ID dans le catalogue`, inline: false });
    embeds[0].fields = fields;
    embeds[embeds.length - 1].footer = { text: `Encaissé : ${fmt(total)}` };
    embeds[embeds.length - 1].timestamp = new Date().toISOString();

    const detail = chunks(orders.map((o, i) =>
      `**${i + 1}. ${o.client}** *(${o.type})* — ${fmt(totalOrder(o))}\n` +
      o.items.map((x) => `  ${x.qte} × ${lib(x)}`).join("\n") + (o.notes ? `\n  📝 ${o.notes}` : "")), 3800);

    const post = async (payload: unknown) => {
      const r = await fetch(webhook + "?wait=true", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (!r.ok) throw new Error("Discord a répondu " + r.status + " " + (await r.text()).slice(0, 200));
    };
    await post({
      username: "Compagnie de l'Empire Oriental",
      content: roleId ? `<@&${roleId}> nouvelle commande de permanence` : "Nouvelle commande de permanence",
      allowed_mentions: { roles: roleId ? [roleId] : [] },
      embeds: embeds.slice(0, 10),
    });
    for (let i = 0; i < detail.length; i++) {
      await post({
        username: "Compagnie de l'Empire Oriental", allowed_mentions: { parse: [] },
        embeds: [{ title: i === 0 ? `🧾 Détail par client — ${titre}` : "🧾 (suite)", description: detail[i], color: 0x6d5d49 }],
      });
    }

    await admin.from("permanences").update({ discord: true, envoye_le: new Date().toISOString() }).eq("id", p.id);
    return json({ ok: true });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 500);
  }
});
