-- =====================================================================
--  Compagnie de l'Empire Oriental — schéma Supabase
--  À coller dans Supabase > SQL Editor > New query, puis "Run".
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Profils (un par compte) : rôle + intendant rattaché
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id        uuid primary key references auth.users(id) on delete cascade,
  login     text not null unique,
  role      text not null default 'intendant' check (role in ('admin', 'intendant')),
  intendant text
);

-- Crée le profil automatiquement à la création d'un compte.
-- Le rôle vient de app_metadata (modifiable uniquement côté serveur),
-- jamais des données envoyées par l'utilisateur.
create or replace function public.nouveau_profil()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, login, role, intendant)
  values (
    new.id,
    lower(coalesce(new.raw_app_meta_data->>'login', split_part(new.email, '@', 1))),
    case when new.raw_app_meta_data->>'role' = 'admin' then 'admin' else 'intendant' end,
    new.raw_app_meta_data->>'intendant'
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.nouveau_profil();

-- Fonctions utilitaires pour les règles d'accès
create or replace function public.est_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create or replace function public.mon_intendant()
returns text language sql stable security definer set search_path = public as $$
  select intendant from public.profiles where id = auth.uid();
$$;

-- ---------------------------------------------------------------------
-- 2. Catalogue (lisible par tous les connectés, modifiable par l'admin)
-- ---------------------------------------------------------------------
create table if not exists public.catalogue (
  nom       text primary key,
  cat       text not null,
  fourni    text not null default '',
  prix      integer not null check (prix >= 0),
  variantes jsonb,            -- ex. ["Blanc","Bleu"] ou null
  note      text,
  ordre     double precision not null default 0
);

-- ID pour le give : table séparée, lisible UNIQUEMENT par l'admin
create table if not exists public.catalogue_ids (
  nom      text primary key references public.catalogue(nom) on update cascade on delete cascade,
  item_id  text,
  var_ids  jsonb              -- ex. {"Blanc":"0A1B2C"}
);

-- ---------------------------------------------------------------------
-- 3. Permanences clôturées (historique partagé)
-- ---------------------------------------------------------------------
create table if not exists public.permanences (
  id          uuid primary key default gen_random_uuid(),
  intendant   text not null,
  coffre      text not null,
  lieu        text not null,
  date        date not null,
  orders      jsonb not null,
  livraisons  jsonb not null default '{}'::jsonb,   -- { idCommande: date de livraison }
  cree_par    uuid default auth.uid() references auth.users(id) on delete set null,
  cloture_le  timestamptz not null default now(),
  discord     boolean not null default false,
  envoye_le   timestamptz
);

-- ---------------------------------------------------------------------
-- 4. Règles d'accès (Row Level Security)
-- ---------------------------------------------------------------------
alter table public.profiles      enable row level security;
alter table public.catalogue     enable row level security;
alter table public.catalogue_ids enable row level security;
alter table public.permanences   enable row level security;

-- Profils : chacun voit le sien, l'admin voit tout. Aucune écriture directe.
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.est_admin());

-- Catalogue
drop policy if exists catalogue_select on public.catalogue;
drop policy if exists catalogue_admin  on public.catalogue;
create policy catalogue_select on public.catalogue for select to authenticated using (true);
create policy catalogue_admin  on public.catalogue for all    to authenticated
  using (public.est_admin()) with check (public.est_admin());

-- ID de give : admin uniquement
drop policy if exists catalogue_ids_admin on public.catalogue_ids;
create policy catalogue_ids_admin on public.catalogue_ids for all to authenticated
  using (public.est_admin()) with check (public.est_admin());

-- Permanences : l'intendant voit / crée les siennes, l'admin tout
drop policy if exists perm_select on public.permanences;
drop policy if exists perm_insert on public.permanences;
drop policy if exists perm_update on public.permanences;
drop policy if exists perm_delete on public.permanences;
create policy perm_select on public.permanences for select to authenticated
  using (public.est_admin() or intendant = public.mon_intendant());
create policy perm_insert on public.permanences for insert to authenticated
  with check ((public.est_admin() or intendant = public.mon_intendant()) and discord = false);
create policy perm_update on public.permanences for update to authenticated
  using (public.est_admin() or intendant = public.mon_intendant())
  with check (public.est_admin() or intendant = public.mon_intendant());
create policy perm_delete on public.permanences for delete to authenticated
  using (public.est_admin());

-- Une fois clôturée, seule la colonne "livraisons" est modifiable depuis le site
-- (le statut Discord est mis à jour uniquement par la fonction serveur).
revoke update on public.permanences from authenticated, anon;
grant  update (livraisons) on public.permanences to authenticated;

-- Aucun accès pour les visiteurs non connectés
revoke all on public.profiles, public.catalogue, public.catalogue_ids, public.permanences from anon;
